﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Sistem_Control_Autobus
{
    public partial class Label_registro_info : Form
    {
        string connectionString = "Data Source=tu_servidor;Initial Catalog=nombre_basedatos;Integrated Security=True";

        public Label_registro_info()
        {
            InitializeComponent();
        }
        private SqlConnection CreateConnection()
        {
            //CONEXIÓN A BASE DE DATOS

            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
                return connection;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al conectar con la base de datos: " + ex.Message, "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        //IMPLEMENTACIÓN DEL FRONT...
        private void Form1_Load(object sender, EventArgs e)
        {
            lb_fecha.Text = DateTime.Today.Date.ToString("d");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textbox_nombre.Text == "" && textbox_apellido.Text == "" && textbox_fecha_nacimiento.Text == "" && textbox_cedula.Text == "")
            {
                MessageBox.Show("Debe ingresar la Información Completa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            

                else if (textbox_nombre.Text == "")
            {
                MessageBox.Show("Debe ingresar el nombre!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_apellido.Text == "")
            {
                MessageBox.Show("Debe ingresar el Apellido!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_fecha_nacimiento.Text == "")
            {
                MessageBox.Show("Debe ingresar la Fecha de Nacimiento!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_cedula.Text == "")
            {
                MessageBox.Show("Debe de ingresar la Cédula!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }


            else
            {
                ListViewItem item = new ListViewItem(textbox_nombre.Text);
                item.SubItems.Add(textbox_apellido.Text);
                item.SubItems.Add(textbox_fecha_nacimiento.Text);
                item.SubItems.Add(textbox_cedula.Text);

                listView2.Items.Add(item);

                combobox_chofer.Items.Clear();

                foreach (ListViewItem listViewItem in listView2.Items)
                {
                    string nombreApellido = listViewItem.SubItems[0].Text + " " + listViewItem.SubItems[1].Text;
                if (!combobox_chofer.Items.Contains(nombreApellido))
                    {
                    combobox_chofer.Items.Add(nombreApellido);
                    }
                    
                }

                string nombreSeleccionado = textbox_nombre.Text;
                string apellidoSeleccionado = textbox_apellido.Text;
                string fechaNacimientoSeleccionada = textbox_fecha_nacimiento.Text;
                string cedulaSeleccionada = textbox_cedula.Text;

                MessageBox.Show($"Nombre Registrado: {nombreSeleccionado}\nApellido Registrado: {apellidoSeleccionado}\nFecha de Nacimiento Registrada: {fechaNacimientoSeleccionada}\nCédula Registrada: {cedulaSeleccionada}", "Datos Registrados Completos", MessageBoxButtons.OK, MessageBoxIcon.Information);

                textbox_nombre.Clear();
                textbox_apellido.Clear();
                textbox_fecha_nacimiento.Clear();
                textbox_cedula.Clear();
            }

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void textbox_nombre_TextChanged(object sender, EventArgs e)
        {


        }

        private void textbox_apellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_fecha_nacimiento_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_cedula_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_modelo_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_placa_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_año_TextChanged(object sender, EventArgs e)
        {

        }
        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {

                DialogResult result = MessageBox.Show("¿Está seguro de que desea eliminar la selección?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    listView1.Items.Remove(listView1.SelectedItems[0]);
                }
                else
                {
                    MessageBox.Show("No hay elementos seleccionados para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btn_seleccionar_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveFileDialog.Title = "Guardar como";
            saveFileDialog.FileName = "Registro Completo de la Selección.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Marca\tModelo\tPlaca\tAño");

                foreach (ListViewItem item in listView1.Items)
                {
                    sb.AppendLine($"{item.SubItems[0].Text}\t{item.SubItems[1].Text}\t{item.SubItems[2].Text}");
                }

                File.WriteAllText(saveFileDialog.FileName, sb.ToString());

                MessageBox.Show("Archivo guardado exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void lb_chofer_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
 
  
        private void btn_registro_ruta_Click(object sender, EventArgs e)
        {

        }

        private void tabpage_Registro_completo_Click(object sender, EventArgs e)
        {

        }

        private void tb_registro_completo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_completo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_autobus_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tb_chofer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_registro_autobus_Click(object sender, EventArgs e)
        {
            if (textbox_marca.Text == "" && textbox_modelo.Text == "" && textbox_placa.Text == "" && textbox_año.Text == "")
            {
                MessageBox.Show("Debe ingresar la Información Completa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (textbox_marca.Text == "")
            {
                MessageBox.Show("Debe ingresar la marca!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_modelo.Text == "")
            {
                MessageBox.Show("Debe ingresar el modelo!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_placa.Text == "")
            {
                MessageBox.Show("Debe ingresar la placa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_año.Text == "")
            {
                MessageBox.Show("Debe de ingresar el año!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else
            {
                ListViewItem item = new ListViewItem(textbox_marca.Text);
                item.SubItems.Add(textbox_modelo.Text);
                item.SubItems.Add(textbox_placa.Text);
                item.SubItems.Add(textbox_año.Text);

                listView4.Items.Add(item);

                combobox_autobus.Items.Clear();

                foreach (ListViewItem listViewItem in listView4.Items)
                {
                    string marcamodeloaño = listViewItem.SubItems[0].Text + " " + listViewItem.SubItems[1].Text+ " "+ listViewItem.SubItems[3].Text;
                    if (!combobox_autobus.Items.Contains(marcamodeloaño))
                    {
                        combobox_autobus.Items.Add(marcamodeloaño);
                    }

                }

                string marcaSeleccionada = textbox_marca.Text;
                string modeloSeleccionado = textbox_modelo.Text;
                string placaSeleccionada = textbox_placa.Text;
                string añoSeleccionado = textbox_año.Text;

                MessageBox.Show($"Marca Registrada: {marcaSeleccionada}\nModelo Registrado: {modeloSeleccionado}\nPlaca Registrada: {placaSeleccionada}\nAño Registrado: {añoSeleccionado}", "Datos Registrados Completos", MessageBoxButtons.OK, MessageBoxIcon.Information);

                textbox_marca.Clear();
                textbox_modelo.Clear();
                textbox_placa.Clear();
                textbox_año.Clear();

            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (combobox_chofer.SelectedIndex == -1 && combobox_autobus.SelectedIndex == -1 && combobox_ruta.SelectedIndex == -1)
            {
                MessageBox.Show("Debe ingresar la Información Completa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else if (combobox_chofer.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar el chófer!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else if (combobox_autobus.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar el autobús!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else if (combobox_ruta.SelectedIndex == -1)
            {
                MessageBox.Show("Debe seleccionar la ruta!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            else if (combobox_hora2.SelectedIndex == -1)
            {
                MessageBox.Show("Debe ingresar la hora!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                ListViewItem item = new ListViewItem(combobox_chofer.SelectedItem.ToString());
                item.SubItems.Add(combobox_autobus.SelectedItem.ToString());
                item.SubItems.Add(combobox_ruta.SelectedItem.ToString());
                item.SubItems.Add(combobox_hora2.SelectedItem.ToString());

                listView1.Items.Add(item);

                string choferSeleccionado = combobox_chofer.SelectedItem.ToString();
                string autobusSeleccionado = combobox_autobus.SelectedItem.ToString();
                string rutaSeleccionada = combobox_ruta.SelectedItem.ToString();
                string horaSeleccionada = combobox_hora2.SelectedItem.ToString();

                MessageBox.Show($"Chofer Seleccionado: {choferSeleccionado}\nAutobús Seleccionado: {autobusSeleccionado}\nRuta Seleccionada: {rutaSeleccionada}\nHora Resgistrada: {horaSeleccionada}", "Datos Registrados Completos", MessageBoxButtons.OK, MessageBoxIcon.Information);

                combobox_chofer.SelectedIndex = -1;
                combobox_autobus.SelectedIndex = -1;
                combobox_ruta.SelectedIndex = -1;
                combobox_hora2.SelectedIndex = -1;

            }



        }

        private void comboBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lb_fecha_Click(object sender, EventArgs e)
        {

        }

        private void listView4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabpage_chofer_Click(object sender, EventArgs e)
        {

        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count > 0)
            {

                DialogResult result = MessageBox.Show("¿Está seguro de que desea eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    listView2.Items.Remove(listView2.SelectedItems[0]);
                }
                else
                {
                    MessageBox.Show("No hay elementos seleccionados para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveFileDialog.Title = "Guardar como";
            saveFileDialog.FileName = "Registro del Chofer.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Nombre\tApellido\tFecha de Nacimiento\tCédula");

                foreach (ListViewItem item in listView2.Items)
                {
                    sb.AppendLine($"{item.SubItems[0].Text}\t{item.SubItems[1].Text}\t{item.SubItems[2].Text}\t{item.SubItems[3].Text}");
                }

                File.WriteAllText(saveFileDialog.FileName, sb.ToString());

                MessageBox.Show("Archivo guardado exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (listView4.SelectedItems.Count > 0)
            {

                DialogResult result = MessageBox.Show("¿Está seguro de que desea eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    listView4.Items.Remove(listView4.SelectedItems[0]);
                }
                else
                {
                    MessageBox.Show("No hay elementos seleccionados para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void listView3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (combobox_ruta2.SelectedIndex == -1 && combobox_hora.SelectedIndex == -1)
            {
                MessageBox.Show("Debe ingresar la Información Completa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else if (combobox_ruta2.SelectedIndex == -1)
            {
                MessageBox.Show("Debe ingresar la ruta!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (combobox_hora.SelectedIndex == -1)
            {
                MessageBox.Show("Debe ingresar la hora!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else

            {
                ListViewItem item = new ListViewItem(combobox_ruta2.SelectedItem.ToString());
                item.SubItems.Add(combobox_hora.SelectedItem.ToString());

                listView3.Items.Add(item);

                foreach (ListViewItem listViewItem in listView3.Items)
                {
                    string ruta = listViewItem.SubItems[0].Text;
                    if (!combobox_ruta.Items.Contains(ruta))
                    {
                        combobox_ruta.Items.Add(ruta);
                    }
                    
                }
                foreach (ListViewItem listViewItem in listView3.Items)
                {
                    string hora = listViewItem.SubItems[1].Text;
                    if (!combobox_hora2.Items.Contains(hora))
                    {
                        combobox_hora2.Items.Add(hora);
                    }
                }

                    string rutaSeleccionada = combobox_ruta2.SelectedItem.ToString();
                string horaSeleccionada = combobox_hora.SelectedItem.ToString();


                MessageBox.Show($"Ruta Registrada: {rutaSeleccionada}\nHora Registrado: {horaSeleccionada}", "Datos Registrados Completos", MessageBoxButtons.OK, MessageBoxIcon.Information);

                combobox_ruta2.SelectedItem = -1;
                combobox_hora.SelectedItem = -1;
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            if (listView3.SelectedItems.Count > 0)
            {

                DialogResult result = MessageBox.Show("¿Está seguro de que desea eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    listView3.Items.Remove(listView3.SelectedItems[0]);
                }
                else
                {
                    MessageBox.Show("No hay elementos seleccionados para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void combobox_hora_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void combobox_ruta2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveFileDialog.Title = "Guardar como";
            saveFileDialog.FileName = "Regsitro de la Ruta.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Ruta\tHora");

                foreach (ListViewItem item in listView3.Items)
                {
                    sb.AppendLine($"{item.SubItems[0].Text}\t{item.SubItems[1].Text}");
                }

                File.WriteAllText(saveFileDialog.FileName, sb.ToString());

                MessageBox.Show("Archivo guardado exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_seleccionar_registro_autobus_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveFileDialog.Title = "Guardar como";
            saveFileDialog.FileName = "Registro del Autobús.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Marca\tModelo\tPlaca\tAño");

                foreach (ListViewItem item in listView4.Items)
                {
                    sb.AppendLine($"{item.SubItems[0].Text}\t{item.SubItems[1].Text}\t{item.SubItems[2].Text}\t{item.SubItems[3].Text}");
                }

                File.WriteAllText(saveFileDialog.FileName, sb.ToString());

                MessageBox.Show("Archivo guardado exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

//FIN.