﻿namespace Sistem_Control_Autobus
{
    partial class Label_registro_info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Label_registro_info));
            this.label_registro_chofer = new System.Windows.Forms.Label();
            this.btn_seleccionar_registro_completo = new System.Windows.Forms.Button();
            this.btn_eliminar_resgitro_completo = new System.Windows.Forms.Button();
            this.tabpage_Registro_completo = new System.Windows.Forms.TabPage();
            this.combobox_hora2 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btn_registrar = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.combobox_ruta = new System.Windows.Forms.ComboBox();
            this.combobox_autobus = new System.Windows.Forms.ComboBox();
            this.combobox_chofer = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabpage_autobus = new System.Windows.Forms.TabPage();
            this.btn_seleccionar_registro_autobus = new System.Windows.Forms.Button();
            this.btn_eliminar_registro_autobus = new System.Windows.Forms.Button();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.btn_registro_autobus = new System.Windows.Forms.Button();
            this.textbox_marca = new System.Windows.Forms.TextBox();
            this.textbox_modelo = new System.Windows.Forms.TextBox();
            this.textbox_placa = new System.Windows.Forms.TextBox();
            this.textbox_año = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tc_registro_tabla = new System.Windows.Forms.TabControl();
            this.tabpage_chofer = new System.Windows.Forms.TabPage();
            this.btn_seleccionar_registro_chofer = new System.Windows.Forms.Button();
            this.btn_eliminar_registro_chofer = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.btn_registro_chofer = new System.Windows.Forms.Button();
            this.label_nombre = new System.Windows.Forms.Label();
            this.label_apellido = new System.Windows.Forms.Label();
            this.label_fecha_nacimiento = new System.Windows.Forms.Label();
            this.label_cedula = new System.Windows.Forms.Label();
            this.textbox_nombre = new System.Windows.Forms.TextBox();
            this.textbox_fecha_nacimiento = new System.Windows.Forms.TextBox();
            this.textbox_apellido = new System.Windows.Forms.TextBox();
            this.textbox_cedula = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.combobox_ruta2 = new System.Windows.Forms.ComboBox();
            this.combobox_hora = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label7 = new System.Windows.Forms.Label();
            this.lb_fecha = new System.Windows.Forms.Label();
            this.tabpage_Registro_completo.SuspendLayout();
            this.tabpage_autobus.SuspendLayout();
            this.tc_registro_tabla.SuspendLayout();
            this.tabpage_chofer.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_registro_chofer
            // 
            this.label_registro_chofer.AutoSize = true;
            this.label_registro_chofer.Font = new System.Drawing.Font("Unispace", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_registro_chofer.Location = new System.Drawing.Point(374, 31);
            this.label_registro_chofer.Name = "label_registro_chofer";
            this.label_registro_chofer.Size = new System.Drawing.Size(338, 34);
            this.label_registro_chofer.TabIndex = 0;
            this.label_registro_chofer.Text = "Registro de Control";
            this.label_registro_chofer.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_seleccionar_registro_completo
            // 
            this.btn_seleccionar_registro_completo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_seleccionar_registro_completo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_seleccionar_registro_completo.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_seleccionar_registro_completo.Location = new System.Drawing.Point(884, 579);
            this.btn_seleccionar_registro_completo.Name = "btn_seleccionar_registro_completo";
            this.btn_seleccionar_registro_completo.Size = new System.Drawing.Size(117, 30);
            this.btn_seleccionar_registro_completo.TabIndex = 37;
            this.btn_seleccionar_registro_completo.Text = "Seleccionar";
            this.btn_seleccionar_registro_completo.UseVisualStyleBackColor = false;
            this.btn_seleccionar_registro_completo.Click += new System.EventHandler(this.btn_seleccionar_Click);
            // 
            // btn_eliminar_resgitro_completo
            // 
            this.btn_eliminar_resgitro_completo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_eliminar_resgitro_completo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_eliminar_resgitro_completo.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar_resgitro_completo.Location = new System.Drawing.Point(780, 579);
            this.btn_eliminar_resgitro_completo.Name = "btn_eliminar_resgitro_completo";
            this.btn_eliminar_resgitro_completo.Size = new System.Drawing.Size(95, 30);
            this.btn_eliminar_resgitro_completo.TabIndex = 38;
            this.btn_eliminar_resgitro_completo.Text = "Eliminar ";
            this.btn_eliminar_resgitro_completo.UseVisualStyleBackColor = false;
            this.btn_eliminar_resgitro_completo.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // tabpage_Registro_completo
            // 
            this.tabpage_Registro_completo.BackColor = System.Drawing.Color.GhostWhite;
            this.tabpage_Registro_completo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabpage_Registro_completo.Controls.Add(this.combobox_hora2);
            this.tabpage_Registro_completo.Controls.Add(this.label14);
            this.tabpage_Registro_completo.Controls.Add(this.btn_registrar);
            this.tabpage_Registro_completo.Controls.Add(this.listView1);
            this.tabpage_Registro_completo.Controls.Add(this.btn_seleccionar_registro_completo);
            this.tabpage_Registro_completo.Controls.Add(this.btn_eliminar_resgitro_completo);
            this.tabpage_Registro_completo.Controls.Add(this.combobox_ruta);
            this.tabpage_Registro_completo.Controls.Add(this.combobox_autobus);
            this.tabpage_Registro_completo.Controls.Add(this.combobox_chofer);
            this.tabpage_Registro_completo.Controls.Add(this.label12);
            this.tabpage_Registro_completo.Controls.Add(this.label11);
            this.tabpage_Registro_completo.Controls.Add(this.label10);
            this.tabpage_Registro_completo.Controls.Add(this.label9);
            this.tabpage_Registro_completo.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabpage_Registro_completo.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabpage_Registro_completo.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tabpage_Registro_completo.Location = new System.Drawing.Point(4, 29);
            this.tabpage_Registro_completo.Name = "tabpage_Registro_completo";
            this.tabpage_Registro_completo.Padding = new System.Windows.Forms.Padding(3);
            this.tabpage_Registro_completo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabpage_Registro_completo.Size = new System.Drawing.Size(1011, 617);
            this.tabpage_Registro_completo.TabIndex = 3;
            this.tabpage_Registro_completo.Text = "Registro Completo";
            this.tabpage_Registro_completo.Click += new System.EventHandler(this.tabpage_Registro_completo_Click);
            // 
            // combobox_hora2
            // 
            this.combobox_hora2.FormattingEnabled = true;
            this.combobox_hora2.Location = new System.Drawing.Point(677, 143);
            this.combobox_hora2.Name = "combobox_hora2";
            this.combobox_hora2.Size = new System.Drawing.Size(198, 28);
            this.combobox_hora2.TabIndex = 42;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(507, 146);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(164, 20);
            this.label14.TabIndex = 41;
            this.label14.Text = "Selección de Hora:";
            // 
            // btn_registrar
            // 
            this.btn_registrar.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_registrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_registrar.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registrar.Location = new System.Drawing.Point(884, 141);
            this.btn_registrar.Name = "btn_registrar";
            this.btn_registrar.Size = new System.Drawing.Size(115, 33);
            this.btn_registrar.TabIndex = 40;
            this.btn_registrar.Text = "Registrar";
            this.btn_registrar.UseVisualStyleBackColor = false;
            this.btn_registrar.Click += new System.EventHandler(this.button2_Click);
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader10,
            this.columnHeader13});
            this.listView1.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(5, 194);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1000, 379);
            this.listView1.TabIndex = 39;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Chofer";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 217;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Autobús";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 270;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Ruta";
            this.columnHeader10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader10.Width = 349;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Hora";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader13.Width = 164;
            // 
            // combobox_ruta
            // 
            this.combobox_ruta.FormattingEnabled = true;
            this.combobox_ruta.Location = new System.Drawing.Point(610, 81);
            this.combobox_ruta.Name = "combobox_ruta";
            this.combobox_ruta.Size = new System.Drawing.Size(265, 28);
            this.combobox_ruta.TabIndex = 37;
            // 
            // combobox_autobus
            // 
            this.combobox_autobus.FormattingEnabled = true;
            this.combobox_autobus.Location = new System.Drawing.Point(229, 140);
            this.combobox_autobus.Name = "combobox_autobus";
            this.combobox_autobus.Size = new System.Drawing.Size(272, 28);
            this.combobox_autobus.TabIndex = 37;
            this.combobox_autobus.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // combobox_chofer
            // 
            this.combobox_chofer.FormattingEnabled = true;
            this.combobox_chofer.Location = new System.Drawing.Point(220, 84);
            this.combobox_chofer.Name = "combobox_chofer";
            this.combobox_chofer.Size = new System.Drawing.Size(221, 28);
            this.combobox_chofer.TabIndex = 37;
            this.combobox_chofer.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged_2);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(447, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(157, 20);
            this.label12.TabIndex = 35;
            this.label12.Text = "Selección de ruta:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(30, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(193, 20);
            this.label11.TabIndex = 36;
            this.label11.Text = "Selección de Autobús:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(34, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(180, 20);
            this.label10.TabIndex = 35;
            this.label10.Text = "Selección de Chófer:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Bright", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(347, 36);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(325, 20);
            this.label9.TabIndex = 34;
            this.label9.Text = "Registro completo de la Selección";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // tabpage_autobus
            // 
            this.tabpage_autobus.BackColor = System.Drawing.Color.GhostWhite;
            this.tabpage_autobus.Controls.Add(this.btn_seleccionar_registro_autobus);
            this.tabpage_autobus.Controls.Add(this.btn_eliminar_registro_autobus);
            this.tabpage_autobus.Controls.Add(this.listView4);
            this.tabpage_autobus.Controls.Add(this.label2);
            this.tabpage_autobus.Controls.Add(this.btn_registro_autobus);
            this.tabpage_autobus.Controls.Add(this.textbox_marca);
            this.tabpage_autobus.Controls.Add(this.textbox_modelo);
            this.tabpage_autobus.Controls.Add(this.textbox_placa);
            this.tabpage_autobus.Controls.Add(this.textbox_año);
            this.tabpage_autobus.Controls.Add(this.label3);
            this.tabpage_autobus.Controls.Add(this.label4);
            this.tabpage_autobus.Controls.Add(this.label5);
            this.tabpage_autobus.Controls.Add(this.label6);
            this.tabpage_autobus.Location = new System.Drawing.Point(4, 29);
            this.tabpage_autobus.Name = "tabpage_autobus";
            this.tabpage_autobus.Padding = new System.Windows.Forms.Padding(3);
            this.tabpage_autobus.Size = new System.Drawing.Size(1011, 617);
            this.tabpage_autobus.TabIndex = 1;
            this.tabpage_autobus.Text = "Registro de Autobús";
            this.tabpage_autobus.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // btn_seleccionar_registro_autobus
            // 
            this.btn_seleccionar_registro_autobus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_seleccionar_registro_autobus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_seleccionar_registro_autobus.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_seleccionar_registro_autobus.Location = new System.Drawing.Point(888, 583);
            this.btn_seleccionar_registro_autobus.Name = "btn_seleccionar_registro_autobus";
            this.btn_seleccionar_registro_autobus.Size = new System.Drawing.Size(117, 30);
            this.btn_seleccionar_registro_autobus.TabIndex = 42;
            this.btn_seleccionar_registro_autobus.Text = "Seleccionar";
            this.btn_seleccionar_registro_autobus.UseVisualStyleBackColor = false;
            this.btn_seleccionar_registro_autobus.Click += new System.EventHandler(this.btn_seleccionar_registro_autobus_Click);
            // 
            // btn_eliminar_registro_autobus
            // 
            this.btn_eliminar_registro_autobus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_eliminar_registro_autobus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_eliminar_registro_autobus.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar_registro_autobus.Location = new System.Drawing.Point(784, 583);
            this.btn_eliminar_registro_autobus.Name = "btn_eliminar_registro_autobus";
            this.btn_eliminar_registro_autobus.Size = new System.Drawing.Size(95, 30);
            this.btn_eliminar_registro_autobus.TabIndex = 43;
            this.btn_eliminar_registro_autobus.Text = "Eliminar ";
            this.btn_eliminar_registro_autobus.UseVisualStyleBackColor = false;
            this.btn_eliminar_registro_autobus.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // listView4
            // 
            this.listView4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9});
            this.listView4.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.listView4.FullRowSelect = true;
            this.listView4.GridLines = true;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(183, 186);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(657, 383);
            this.listView4.TabIndex = 41;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            this.listView4.SelectedIndexChanged += new System.EventHandler(this.listView4_SelectedIndexChanged);
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Marca";
            this.columnHeader6.Width = 142;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Modelo";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 168;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Placa";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 170;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Año";
            this.columnHeader9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader9.Width = 172;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Bright", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(404, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(209, 20);
            this.label2.TabIndex = 24;
            this.label2.Text = "Registro del Autobús";
            // 
            // btn_registro_autobus
            // 
            this.btn_registro_autobus.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_registro_autobus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_registro_autobus.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registro_autobus.Location = new System.Drawing.Point(883, 129);
            this.btn_registro_autobus.Name = "btn_registro_autobus";
            this.btn_registro_autobus.Size = new System.Drawing.Size(96, 30);
            this.btn_registro_autobus.TabIndex = 12;
            this.btn_registro_autobus.Text = "Agregar";
            this.btn_registro_autobus.UseVisualStyleBackColor = false;
            this.btn_registro_autobus.Click += new System.EventHandler(this.btn_registro_autobus_Click);
            // 
            // textbox_marca
            // 
            this.textbox_marca.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_marca.Location = new System.Drawing.Point(91, 75);
            this.textbox_marca.Multiline = true;
            this.textbox_marca.Name = "textbox_marca";
            this.textbox_marca.Size = new System.Drawing.Size(200, 22);
            this.textbox_marca.TabIndex = 25;
            this.textbox_marca.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textbox_modelo
            // 
            this.textbox_modelo.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_modelo.Location = new System.Drawing.Point(379, 76);
            this.textbox_modelo.Multiline = true;
            this.textbox_modelo.Name = "textbox_modelo";
            this.textbox_modelo.Size = new System.Drawing.Size(215, 22);
            this.textbox_modelo.TabIndex = 28;
            this.textbox_modelo.TextChanged += new System.EventHandler(this.textbox_modelo_TextChanged);
            // 
            // textbox_placa
            // 
            this.textbox_placa.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_placa.Location = new System.Drawing.Point(672, 76);
            this.textbox_placa.Multiline = true;
            this.textbox_placa.Name = "textbox_placa";
            this.textbox_placa.Size = new System.Drawing.Size(108, 22);
            this.textbox_placa.TabIndex = 30;
            this.textbox_placa.TextChanged += new System.EventHandler(this.textbox_placa_TextChanged);
            // 
            // textbox_año
            // 
            this.textbox_año.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_año.Location = new System.Drawing.Point(846, 76);
            this.textbox_año.Multiline = true;
            this.textbox_año.Name = "textbox_año";
            this.textbox_año.Size = new System.Drawing.Size(133, 22);
            this.textbox_año.TabIndex = 32;
            this.textbox_año.TextChanged += new System.EventHandler(this.textbox_año_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Marca:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 20);
            this.label4.TabIndex = 27;
            this.label4.Text = "Modelo:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(611, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Placa:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(793, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "Año:";
            // 
            // tc_registro_tabla
            // 
            this.tc_registro_tabla.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tc_registro_tabla.Controls.Add(this.tabpage_chofer);
            this.tc_registro_tabla.Controls.Add(this.tabpage_autobus);
            this.tc_registro_tabla.Controls.Add(this.tabPage1);
            this.tc_registro_tabla.Controls.Add(this.tabpage_Registro_completo);
            this.tc_registro_tabla.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tc_registro_tabla.Location = new System.Drawing.Point(25, 92);
            this.tc_registro_tabla.Name = "tc_registro_tabla";
            this.tc_registro_tabla.SelectedIndex = 0;
            this.tc_registro_tabla.Size = new System.Drawing.Size(1019, 650);
            this.tc_registro_tabla.TabIndex = 46;
            // 
            // tabpage_chofer
            // 
            this.tabpage_chofer.BackColor = System.Drawing.Color.GhostWhite;
            this.tabpage_chofer.Controls.Add(this.btn_seleccionar_registro_chofer);
            this.tabpage_chofer.Controls.Add(this.btn_eliminar_registro_chofer);
            this.tabpage_chofer.Controls.Add(this.listView2);
            this.tabpage_chofer.Controls.Add(this.label1);
            this.tabpage_chofer.Controls.Add(this.btn_registro_chofer);
            this.tabpage_chofer.Controls.Add(this.label_nombre);
            this.tabpage_chofer.Controls.Add(this.label_apellido);
            this.tabpage_chofer.Controls.Add(this.label_fecha_nacimiento);
            this.tabpage_chofer.Controls.Add(this.label_cedula);
            this.tabpage_chofer.Controls.Add(this.textbox_nombre);
            this.tabpage_chofer.Controls.Add(this.textbox_fecha_nacimiento);
            this.tabpage_chofer.Controls.Add(this.textbox_apellido);
            this.tabpage_chofer.Controls.Add(this.textbox_cedula);
            this.tabpage_chofer.Location = new System.Drawing.Point(4, 29);
            this.tabpage_chofer.Name = "tabpage_chofer";
            this.tabpage_chofer.Padding = new System.Windows.Forms.Padding(3);
            this.tabpage_chofer.Size = new System.Drawing.Size(1011, 617);
            this.tabpage_chofer.TabIndex = 0;
            this.tabpage_chofer.Text = "Registro de Chófer";
            this.tabpage_chofer.Click += new System.EventHandler(this.tabpage_chofer_Click);
            // 
            // btn_seleccionar_registro_chofer
            // 
            this.btn_seleccionar_registro_chofer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_seleccionar_registro_chofer.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_seleccionar_registro_chofer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_seleccionar_registro_chofer.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_seleccionar_registro_chofer.Location = new System.Drawing.Point(888, 582);
            this.btn_seleccionar_registro_chofer.Name = "btn_seleccionar_registro_chofer";
            this.btn_seleccionar_registro_chofer.Size = new System.Drawing.Size(117, 30);
            this.btn_seleccionar_registro_chofer.TabIndex = 41;
            this.btn_seleccionar_registro_chofer.Text = "Seleccionar";
            this.btn_seleccionar_registro_chofer.UseVisualStyleBackColor = false;
            this.btn_seleccionar_registro_chofer.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_eliminar_registro_chofer
            // 
            this.btn_eliminar_registro_chofer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_eliminar_registro_chofer.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_eliminar_registro_chofer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_eliminar_registro_chofer.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar_registro_chofer.Location = new System.Drawing.Point(784, 582);
            this.btn_eliminar_registro_chofer.Name = "btn_eliminar_registro_chofer";
            this.btn_eliminar_registro_chofer.Size = new System.Drawing.Size(95, 30);
            this.btn_eliminar_registro_chofer.TabIndex = 42;
            this.btn_eliminar_registro_chofer.Text = "Eliminar ";
            this.btn_eliminar_registro_chofer.UseVisualStyleBackColor = false;
            this.btn_eliminar_registro_chofer.Click += new System.EventHandler(this.button4_Click);
            // 
            // listView2
            // 
            this.listView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader11});
            this.listView2.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(105, 187);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(832, 389);
            this.listView2.TabIndex = 40;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            this.listView2.SelectedIndexChanged += new System.EventHandler(this.listView2_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nombre";
            this.columnHeader1.Width = 177;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Apelllido";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 214;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Fecha de Nacimiento";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 218;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Cédula";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 219;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Bright", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(420, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 20);
            this.label1.TabIndex = 19;
            this.label1.Text = "Registro del Chofer";
            this.label1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // btn_registro_chofer
            // 
            this.btn_registro_chofer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_registro_chofer.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_registro_chofer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_registro_chofer.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registro_chofer.Location = new System.Drawing.Point(886, 119);
            this.btn_registro_chofer.Name = "btn_registro_chofer";
            this.btn_registro_chofer.Size = new System.Drawing.Size(102, 30);
            this.btn_registro_chofer.TabIndex = 11;
            this.btn_registro_chofer.Text = "Agregar";
            this.btn_registro_chofer.UseVisualStyleBackColor = false;
            this.btn_registro_chofer.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_nombre
            // 
            this.label_nombre.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_nombre.AutoSize = true;
            this.label_nombre.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nombre.Location = new System.Drawing.Point(20, 60);
            this.label_nombre.Name = "label_nombre";
            this.label_nombre.Size = new System.Drawing.Size(82, 20);
            this.label_nombre.TabIndex = 15;
            this.label_nombre.Text = "Nombre:";
            // 
            // label_apellido
            // 
            this.label_apellido.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_apellido.AutoSize = true;
            this.label_apellido.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_apellido.Location = new System.Drawing.Point(339, 65);
            this.label_apellido.Name = "label_apellido";
            this.label_apellido.Size = new System.Drawing.Size(85, 20);
            this.label_apellido.TabIndex = 16;
            this.label_apellido.Text = "Apellido:";
            // 
            // label_fecha_nacimiento
            // 
            this.label_fecha_nacimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_fecha_nacimiento.AutoSize = true;
            this.label_fecha_nacimiento.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fecha_nacimiento.Location = new System.Drawing.Point(658, 70);
            this.label_fecha_nacimiento.Name = "label_fecha_nacimiento";
            this.label_fecha_nacimiento.Size = new System.Drawing.Size(189, 20);
            this.label_fecha_nacimiento.TabIndex = 17;
            this.label_fecha_nacimiento.Text = "Fecha de Nacimiento:";
            // 
            // label_cedula
            // 
            this.label_cedula.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_cedula.AutoSize = true;
            this.label_cedula.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cedula.Location = new System.Drawing.Point(20, 101);
            this.label_cedula.Name = "label_cedula";
            this.label_cedula.Size = new System.Drawing.Size(71, 20);
            this.label_cedula.TabIndex = 18;
            this.label_cedula.Text = "Cédula:";
            // 
            // textbox_nombre
            // 
            this.textbox_nombre.BackColor = System.Drawing.SystemColors.Window;
            this.textbox_nombre.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_nombre.Location = new System.Drawing.Point(105, 60);
            this.textbox_nombre.Multiline = true;
            this.textbox_nombre.Name = "textbox_nombre";
            this.textbox_nombre.Size = new System.Drawing.Size(228, 22);
            this.textbox_nombre.TabIndex = 20;
            this.textbox_nombre.TextChanged += new System.EventHandler(this.textbox_nombre_TextChanged);
            // 
            // textbox_fecha_nacimiento
            // 
            this.textbox_fecha_nacimiento.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_fecha_nacimiento.Location = new System.Drawing.Point(850, 70);
            this.textbox_fecha_nacimiento.Multiline = true;
            this.textbox_fecha_nacimiento.Name = "textbox_fecha_nacimiento";
            this.textbox_fecha_nacimiento.Size = new System.Drawing.Size(138, 22);
            this.textbox_fecha_nacimiento.TabIndex = 21;
            this.textbox_fecha_nacimiento.TextChanged += new System.EventHandler(this.textbox_fecha_nacimiento_TextChanged);
            // 
            // textbox_apellido
            // 
            this.textbox_apellido.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_apellido.Location = new System.Drawing.Point(424, 63);
            this.textbox_apellido.Multiline = true;
            this.textbox_apellido.Name = "textbox_apellido";
            this.textbox_apellido.Size = new System.Drawing.Size(228, 22);
            this.textbox_apellido.TabIndex = 22;
            this.textbox_apellido.TextChanged += new System.EventHandler(this.textbox_apellido_TextChanged);
            // 
            // textbox_cedula
            // 
            this.textbox_cedula.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_cedula.Location = new System.Drawing.Point(105, 101);
            this.textbox_cedula.Multiline = true;
            this.textbox_cedula.Name = "textbox_cedula";
            this.textbox_cedula.Size = new System.Drawing.Size(228, 22);
            this.textbox_cedula.TabIndex = 23;
            this.textbox_cedula.TextChanged += new System.EventHandler(this.textbox_cedula_TextChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.GhostWhite;
            this.tabPage1.Controls.Add(this.combobox_ruta2);
            this.tabPage1.Controls.Add(this.combobox_hora);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.listView3);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1011, 617);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Registro de Ruta";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // combobox_ruta2
            // 
            this.combobox_ruta2.FormattingEnabled = true;
            this.combobox_ruta2.Items.AddRange(new object[] {
            "Av. George Washington",
            "Av. Winston Churchill",
            "Av. John F. Kennedy",
            "Av. Máximo Gómez",
            "Av. 27 de Febrero",
            "Av. Independencia",
            "Av. Bolívar",
            "Av. Charles De Gaulle",
            "Av. Hermanas Mirabal",
            "La Sabána",
            "Puente Juan Carlos"});
            this.combobox_ruta2.Location = new System.Drawing.Point(216, 84);
            this.combobox_ruta2.Name = "combobox_ruta2";
            this.combobox_ruta2.Size = new System.Drawing.Size(208, 28);
            this.combobox_ruta2.TabIndex = 51;
            this.combobox_ruta2.SelectedIndexChanged += new System.EventHandler(this.combobox_ruta2_SelectedIndexChanged);
            // 
            // combobox_hora
            // 
            this.combobox_hora.FormattingEnabled = true;
            this.combobox_hora.Items.AddRange(new object[] {
            "(6:30 a.m. - 7:15 a.m.)",
            "(7:00 a.m. - 7:45 a.m.)",
            "(8:00 a.m. - 8:30 a.m.)",
            "(12:00 p.m. - 12:45 p.m.)",
            "(12:30 p.m. - 1:15 p.m.)",
            "(1:00 p.m. - 1:30 p.m.)",
            "(3:00 p.m. - 3:45 p.m.)",
            "(3:45 p.m. - 4:30 p.m.)",
            "(4:30 p.m. - 5:15 p.m.)",
            "(5:15 p.m. - 6:00 p.m.)",
            "(6:00 p.m. - 6:45 p.m.)",
            "(6:45 p.m. - 7:30 p.m.)",
            "(7:30 p.m. -  8:15 p.m.)",
            "(8:15 p.m. -  9:00 p.m.)"});
            this.combobox_hora.Location = new System.Drawing.Point(614, 84);
            this.combobox_hora.Name = "combobox_hora";
            this.combobox_hora.Size = new System.Drawing.Size(208, 28);
            this.combobox_hora.TabIndex = 50;
            this.combobox_hora.SelectedIndexChanged += new System.EventHandler(this.combobox_hora_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(462, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(146, 20);
            this.label13.TabIndex = 49;
            this.label13.Text = "Agregue la hora:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(828, 84);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 30);
            this.button3.TabIndex = 48;
            this.button3.Text = "Agregar";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(68, 87);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 20);
            this.label8.TabIndex = 46;
            this.label8.Text = "Agregue la ruta:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(887, 577);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 30);
            this.button1.TabIndex = 44;
            this.button1.Text = "Seleccionar";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(786, 577);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 30);
            this.button2.TabIndex = 45;
            this.button2.Text = "Eliminar ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // listView3
            // 
            this.listView3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.listView3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader12,
            this.columnHeader15});
            this.listView3.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.listView3.FullRowSelect = true;
            this.listView3.GridLines = true;
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(272, 156);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(492, 410);
            this.listView3.TabIndex = 40;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            this.listView3.SelectedIndexChanged += new System.EventHandler(this.listView3_SelectedIndexChanged);
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Ruta";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader12.Width = 246;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Hora";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 244;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Bright", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(413, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(187, 20);
            this.label7.TabIndex = 35;
            this.label7.Text = "Registro de la Ruta";
            // 
            // lb_fecha
            // 
            this.lb_fecha.AutoSize = true;
            this.lb_fecha.Font = new System.Drawing.Font("Unispace", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fecha.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lb_fecha.Location = new System.Drawing.Point(915, 20);
            this.lb_fecha.Name = "lb_fecha";
            this.lb_fecha.Size = new System.Drawing.Size(82, 24);
            this.lb_fecha.TabIndex = 47;
            this.lb_fecha.Text = "label7";
            this.lb_fecha.Click += new System.EventHandler(this.lb_fecha_Click);
            // 
            // Label_registro_info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1074, 754);
            this.Controls.Add(this.lb_fecha);
            this.Controls.Add(this.tc_registro_tabla);
            this.Controls.Add(this.label_registro_chofer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Label_registro_info";
            this.Text = "SISTEMA DE CONTROL DE AUTOBUSES";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabpage_Registro_completo.ResumeLayout(false);
            this.tabpage_Registro_completo.PerformLayout();
            this.tabpage_autobus.ResumeLayout(false);
            this.tabpage_autobus.PerformLayout();
            this.tc_registro_tabla.ResumeLayout(false);
            this.tabpage_chofer.ResumeLayout(false);
            this.tabpage_chofer.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_registro_chofer;
        private System.Windows.Forms.Button btn_seleccionar_registro_completo;
        private System.Windows.Forms.Button btn_eliminar_resgitro_completo;
        private System.Windows.Forms.TabPage tabpage_Registro_completo;
        private System.Windows.Forms.Button btn_registrar;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ComboBox combobox_ruta;
        private System.Windows.Forms.ComboBox combobox_autobus;
        private System.Windows.Forms.ComboBox combobox_chofer;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabpage_autobus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_registro_autobus;
        private System.Windows.Forms.TextBox textbox_marca;
        private System.Windows.Forms.TextBox textbox_modelo;
        private System.Windows.Forms.TextBox textbox_placa;
        private System.Windows.Forms.TextBox textbox_año;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabControl tc_registro_tabla;
        private System.Windows.Forms.TabPage tabpage_chofer;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_registro_chofer;
        private System.Windows.Forms.Label label_nombre;
        private System.Windows.Forms.Label label_apellido;
        private System.Windows.Forms.Label label_fecha_nacimiento;
        private System.Windows.Forms.Label label_cedula;
        private System.Windows.Forms.TextBox textbox_nombre;
        private System.Windows.Forms.TextBox textbox_fecha_nacimiento;
        private System.Windows.Forms.TextBox textbox_apellido;
        private System.Windows.Forms.TextBox textbox_cedula;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.Label lb_fecha;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Button btn_seleccionar_registro_autobus;
        private System.Windows.Forms.Button btn_eliminar_registro_autobus;
        private System.Windows.Forms.Button btn_seleccionar_registro_chofer;
        private System.Windows.Forms.Button btn_eliminar_registro_chofer;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ComboBox combobox_hora;
        private System.Windows.Forms.ComboBox combobox_ruta2;
        private System.Windows.Forms.ComboBox combobox_hora2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ColumnHeader columnHeader13;
    }
}

