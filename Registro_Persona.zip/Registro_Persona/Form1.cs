﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Registro_Persona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //CONEXIÓN A LA BASE DE DATOS
            InitializeComponent();
            string connectionString = "Data Source=NombreServidor;Initial Catalog=NombreBaseDatos;User ID=Usuario;Password=Contraseña";

            
            SqlConnection connection = new SqlConnection(connectionString);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lb_date.Text = DateTime.Today.Date.ToString("d");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
             
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textbox_nombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_fecha_nacimiento_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_apellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void textbox_cedula_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listview_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_registro_persona_Click(object sender, EventArgs e)
        {
            
            if (textbox_nombre.Text == "" && textbox_apellido.Text == "" && textbox_fecha_nacimiento.Text == "" && textbox_cedula.Text == "")
            {
                MessageBox.Show("Debe ingresar la Información Completa!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            else if (textbox_nombre.Text == "")
            {
                MessageBox.Show("Debe ingresar el nombre!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_apellido.Text == "")
            {
                MessageBox.Show("Debe ingresar el Apellido!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_fecha_nacimiento.Text == "")
            {
                MessageBox.Show("Debe ingresar la Fecha de Nacimiento!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (textbox_cedula.Text == "")
            {
                MessageBox.Show("Debe de ingresar la Cédula!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else
            {
                ListViewItem item = new ListViewItem(textbox_nombre.Text);
                item.SubItems.Add(textbox_apellido.Text);
                item.SubItems.Add(textbox_fecha_nacimiento.Text);
                item.SubItems.Add(textbox_cedula.Text);

                listview1.Items.Add(item);

                string nombreSeleccionado = textbox_nombre.Text;
                string apellidoSeleccionado = textbox_apellido.Text;
                string fechaNacimientoSeleccionada = textbox_fecha_nacimiento.Text;
                string cedulaSeleccionada = textbox_cedula.Text;

                MessageBox.Show($"Nombre Registrado: {nombreSeleccionado}\nApellido Registrado: {apellidoSeleccionado}\nFecha de Nacimiento Registrada: {fechaNacimientoSeleccionada}\nCédula Registrada: {cedulaSeleccionada}", "Datos Registrados Completos", MessageBoxButtons.OK, MessageBoxIcon.Information);

                textbox_nombre.Clear();
                textbox_apellido.Clear();
                textbox_fecha_nacimiento.Clear();
                textbox_cedula.Clear();

            }
        }

        private void btn_eliminar_registro_chofer_Click(object sender, EventArgs e)
        {
            var resultado = MessageBox.Show("¿Estás seguro de que quieres cerrar esta ventana?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
           
            if (resultado == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listview1.SelectedItems.Count > 0)
            {

                DialogResult result = MessageBox.Show("¿Está seguro de que desea eliminar el registro?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    listview1.Items.Remove(listview1.SelectedItems[0]);
                }
                else
                {
                    MessageBox.Show("No hay elementos seleccionados para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btn_seleccionar_registro_chofer_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            saveFileDialog.Title = "Guardar como";
            saveFileDialog.FileName = "Registro Civil.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("Nombre\tApellido\tFecha de Nacimiento\tCédula");

                foreach (ListViewItem item in listview1.Items)
                {
                    sb.AppendLine($"{item.SubItems[0].Text}\t{item.SubItems[1].Text}\t{item.SubItems[2].Text}\t{item.SubItems[3].Text}");
                }

                File.WriteAllText(saveFileDialog.FileName, sb.ToString());

                MessageBox.Show("Archivo guardado exitosamente.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_cambiar_color_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.Color = this.BackColor;
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = colorDialog.Color;
            }
        }
                                
        private void label2_Click_2(object sender, EventArgs e)
        {
            
        }

      
    }
}
