﻿namespace Registro_Persona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listview1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_cerrar = new System.Windows.Forms.Button();
            this.label_nombre = new System.Windows.Forms.Label();
            this.textbox_nombre = new System.Windows.Forms.TextBox();
            this.label_apellido = new System.Windows.Forms.Label();
            this.textbox_apellido = new System.Windows.Forms.TextBox();
            this.label_fecha_nacimiento = new System.Windows.Forms.Label();
            this.textbox_fecha_nacimiento = new System.Windows.Forms.TextBox();
            this.label_cedula = new System.Windows.Forms.Label();
            this.textbox_cedula = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_fecha = new System.Windows.Forms.Label();
            this.btn_cambiar_color = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_registro_persona = new System.Windows.Forms.Button();
            this.lb_date = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listview1
            // 
            this.listview1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listview1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listview1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader11});
            this.listview1.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listview1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.listview1.FullRowSelect = true;
            this.listview1.GridLines = true;
            this.listview1.HideSelection = false;
            this.listview1.Location = new System.Drawing.Point(122, 190);
            this.listview1.Name = "listview1";
            this.listview1.Size = new System.Drawing.Size(832, 437);
            this.listview1.TabIndex = 41;
            this.listview1.UseCompatibleStateImageBehavior = false;
            this.listview1.View = System.Windows.Forms.View.Details;
            this.listview1.SelectedIndexChanged += new System.EventHandler(this.listview_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Nombre";
            this.columnHeader1.Width = 177;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Apelllido";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 214;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Fecha de Nacimiento";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 218;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Cédula";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader11.Width = 219;
            // 
            // btn_guardar
            // 
            this.btn_guardar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_guardar.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_guardar.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardar.Location = new System.Drawing.Point(893, 647);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(157, 30);
            this.btn_guardar.TabIndex = 42;
            this.btn_guardar.Text = "Guardar como...";
            this.btn_guardar.UseVisualStyleBackColor = false;
            this.btn_guardar.Click += new System.EventHandler(this.btn_seleccionar_registro_chofer_Click);
            // 
            // btn_cerrar
            // 
            this.btn_cerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cerrar.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_cerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cerrar.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cerrar.Location = new System.Drawing.Point(691, 647);
            this.btn_cerrar.Name = "btn_cerrar";
            this.btn_cerrar.Size = new System.Drawing.Size(95, 30);
            this.btn_cerrar.TabIndex = 43;
            this.btn_cerrar.Text = "Cerrar";
            this.btn_cerrar.UseVisualStyleBackColor = false;
            this.btn_cerrar.Click += new System.EventHandler(this.btn_eliminar_registro_chofer_Click);
            // 
            // label_nombre
            // 
            this.label_nombre.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_nombre.AutoSize = true;
            this.label_nombre.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nombre.Location = new System.Drawing.Point(12, 78);
            this.label_nombre.Name = "label_nombre";
            this.label_nombre.Size = new System.Drawing.Size(82, 20);
            this.label_nombre.TabIndex = 44;
            this.label_nombre.Text = "Nombre:";
            // 
            // textbox_nombre
            // 
            this.textbox_nombre.BackColor = System.Drawing.SystemColors.Window;
            this.textbox_nombre.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_nombre.Location = new System.Drawing.Point(100, 78);
            this.textbox_nombre.Multiline = true;
            this.textbox_nombre.Name = "textbox_nombre";
            this.textbox_nombre.Size = new System.Drawing.Size(155, 22);
            this.textbox_nombre.TabIndex = 45;
            // 
            // label_apellido
            // 
            this.label_apellido.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_apellido.AutoSize = true;
            this.label_apellido.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_apellido.Location = new System.Drawing.Point(261, 81);
            this.label_apellido.Name = "label_apellido";
            this.label_apellido.Size = new System.Drawing.Size(85, 20);
            this.label_apellido.TabIndex = 46;
            this.label_apellido.Text = "Apellido:";
            // 
            // textbox_apellido
            // 
            this.textbox_apellido.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_apellido.Location = new System.Drawing.Point(352, 81);
            this.textbox_apellido.Multiline = true;
            this.textbox_apellido.Name = "textbox_apellido";
            this.textbox_apellido.Size = new System.Drawing.Size(141, 22);
            this.textbox_apellido.TabIndex = 47;
            // 
            // label_fecha_nacimiento
            // 
            this.label_fecha_nacimiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_fecha_nacimiento.AutoSize = true;
            this.label_fecha_nacimiento.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fecha_nacimiento.Location = new System.Drawing.Point(499, 84);
            this.label_fecha_nacimiento.Name = "label_fecha_nacimiento";
            this.label_fecha_nacimiento.Size = new System.Drawing.Size(189, 20);
            this.label_fecha_nacimiento.TabIndex = 48;
            this.label_fecha_nacimiento.Text = "Fecha de Nacimiento:";
            // 
            // textbox_fecha_nacimiento
            // 
            this.textbox_fecha_nacimiento.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_fecha_nacimiento.Location = new System.Drawing.Point(694, 84);
            this.textbox_fecha_nacimiento.Multiline = true;
            this.textbox_fecha_nacimiento.Name = "textbox_fecha_nacimiento";
            this.textbox_fecha_nacimiento.Size = new System.Drawing.Size(101, 22);
            this.textbox_fecha_nacimiento.TabIndex = 49;
            // 
            // label_cedula
            // 
            this.label_cedula.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_cedula.AutoSize = true;
            this.label_cedula.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cedula.Location = new System.Drawing.Point(801, 87);
            this.label_cedula.Name = "label_cedula";
            this.label_cedula.Size = new System.Drawing.Size(71, 20);
            this.label_cedula.TabIndex = 50;
            this.label_cedula.Text = "Cédula:";
            // 
            // textbox_cedula
            // 
            this.textbox_cedula.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_cedula.Location = new System.Drawing.Point(878, 87);
            this.textbox_cedula.Multiline = true;
            this.textbox_cedula.Name = "textbox_cedula";
            this.textbox_cedula.Size = new System.Drawing.Size(163, 22);
            this.textbox_cedula.TabIndex = 51;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Bright", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(426, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 26);
            this.label1.TabIndex = 52;
            this.label1.Text = "Registro Comunitario";
            // 
            // lb_fecha
            // 
            this.lb_fecha.AutoSize = true;
            this.lb_fecha.Font = new System.Drawing.Font("Unispace", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fecha.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.lb_fecha.Location = new System.Drawing.Point(931, 25);
            this.lb_fecha.Name = "lb_fecha";
            this.lb_fecha.Size = new System.Drawing.Size(0, 24);
            this.lb_fecha.TabIndex = 53;
            // 
            // btn_cambiar_color
            // 
            this.btn_cambiar_color.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cambiar_color.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_cambiar_color.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cambiar_color.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cambiar_color.Location = new System.Drawing.Point(16, 12);
            this.btn_cambiar_color.Name = "btn_cambiar_color";
            this.btn_cambiar_color.Size = new System.Drawing.Size(155, 30);
            this.btn_cambiar_color.TabIndex = 54;
            this.btn_cambiar_color.Text = "Cambiar Color";
            this.btn_cambiar_color.UseVisualStyleBackColor = false;
            this.btn_cambiar_color.Click += new System.EventHandler(this.btn_cambiar_color_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(792, 647);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 30);
            this.button2.TabIndex = 55;
            this.button2.Text = "Eliminar ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_registro_persona
            // 
            this.btn_registro_persona.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_registro_persona.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btn_registro_persona.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_registro_persona.Font = new System.Drawing.Font("Lucida Bright", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_registro_persona.Location = new System.Drawing.Point(939, 135);
            this.btn_registro_persona.Name = "btn_registro_persona";
            this.btn_registro_persona.Size = new System.Drawing.Size(102, 30);
            this.btn_registro_persona.TabIndex = 56;
            this.btn_registro_persona.Text = "Agregar";
            this.btn_registro_persona.UseVisualStyleBackColor = false;
            this.btn_registro_persona.Click += new System.EventHandler(this.btn_registro_persona_Click);
            // 
            // lb_date
            // 
            this.lb_date.AutoSize = true;
            this.lb_date.Font = new System.Drawing.Font("Unispace", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_date.Location = new System.Drawing.Point(907, 21);
            this.lb_date.Name = "lb_date";
            this.lb_date.Size = new System.Drawing.Size(82, 24);
            this.lb_date.TabIndex = 57;
            this.lb_date.Text = "label2";
            this.lb_date.Click += new System.EventHandler(this.label2_Click_2);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1062, 689);
            this.Controls.Add(this.lb_date);
            this.Controls.Add(this.btn_registro_persona);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_cambiar_color);
            this.Controls.Add(this.lb_fecha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textbox_cedula);
            this.Controls.Add(this.label_cedula);
            this.Controls.Add(this.textbox_fecha_nacimiento);
            this.Controls.Add(this.label_fecha_nacimiento);
            this.Controls.Add(this.textbox_apellido);
            this.Controls.Add(this.label_apellido);
            this.Controls.Add(this.textbox_nombre);
            this.Controls.Add(this.label_nombre);
            this.Controls.Add(this.btn_cerrar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.listview1);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "REGISTRO COMUNITARIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listview1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button btn_cerrar;
        private System.Windows.Forms.Label label_nombre;
        private System.Windows.Forms.TextBox textbox_nombre;
        private System.Windows.Forms.Label label_apellido;
        private System.Windows.Forms.TextBox textbox_apellido;
        private System.Windows.Forms.Label label_fecha_nacimiento;
        private System.Windows.Forms.TextBox textbox_fecha_nacimiento;
        private System.Windows.Forms.Label label_cedula;
        private System.Windows.Forms.TextBox textbox_cedula;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_fecha;
        private System.Windows.Forms.Button btn_cambiar_color;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_registro_persona;
        private System.Windows.Forms.Label lb_date;
    }
}

